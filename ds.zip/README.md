# 주차 로봇 ROS2 시뮬레이션

하드웨어 없이 두 대의 메카넘 로봇이 주차장에서 빈 자리를 찾아 이동하는 과정을 시뮬레이션합니다.

## 노드 구성

```
sim_cctv           → /parking/target_pose →  nav_controller
(빈 슬롯 발행)                               (경로 계획 + 동기화)
                                                   │
                                    ┌──────────────┼──────────────┐
                                    ▼              ▼              ▼
                              /front/cmd_vel  /rear/cmd_vel   visualizer
                                    │              │         (OpenCV 화면)
                                    ▼              ▼
                              sim_robot(front) sim_robot(rear)
                              (물리 시뮬)       (물리 시뮬)
                                    │              │
                                    ▼              ▼
                              /front/odom     /rear/odom → nav_controller
```

## 설치

```bash
# ROS2 Humble 이상 필요
# OpenCV 필요: pip install opencv-python

cd parking_sim_ws
colcon build
source install/setup.bash
```

## 실행

### 방법 1: 한 줄로 전부 실행
```bash
ros2 launch parking_sim sim_launch.py
```

### 방법 2: 터미널 5개로 개별 실행 (디버깅용)
```bash
# 터미널 1: 앞 로봇
ros2 run parking_sim robot --ros-args -p name:=front -p start_x:=0.70 -p start_y:=0.60 -p start_theta:=1.5708

# 터미널 2: 뒤 로봇
ros2 run parking_sim robot --ros-args -p name:=rear -p start_x:=0.70 -p start_y:=0.85 -p start_theta:=1.5708

# 터미널 3: CCTV
ros2 run parking_sim cctv

# 터미널 4: 컨트롤러
ros2 run parking_sim controller

# 터미널 5: 시각화
ros2 run parking_sim visualizer
```

## 시뮬레이션 화면

- 초록 테두리 = 빈 슬롯
- 빨간 박스 = 점유 슬롯 (차량 있음)
- 주황 사각형 = 앞 로봇 (FRONT)
- 초록 사각형 = 뒤 로봇 (REAR)
- 파란 점 = 가상 강체 중심점
- 빨간 점선 = 두 로봇 연결 (강체 링크)
- 노란 X = 목표 주차 슬롯

## 토픽 모니터링

```bash
# 빈 슬롯 정보
ros2 topic echo /parking/info

# 네비게이션 상태
ros2 topic echo /nav/status

# 앞 로봇 위치
ros2 topic echo /front/odom

# 수동 목표 전송 테스트
ros2 topic pub --once /parking/target_pose geometry_msgs/PoseStamped "{header: {frame_id: 'world'}, pose: {position: {x: 0.4, y: 0.1}}}"
```

## 파일 구조

```
parking_sim_ws/
└── src/parking_sim/
    ├── package.xml
    ├── setup.py
    ├── config/parking.yaml
    ├── launch/sim_launch.py
    └── parking_sim/
        ├── __init__.py
        ├── sim_world.py          # 올인원 실행
        ├── sim_robot.py          # 메카넘 로봇 시뮬레이션
        ├── sim_cctv.py           # CCTV 빈 슬롯 발행
        ├── nav_controller.py     # 네비게이션 + 동기화
        └── visualizer.py         # OpenCV 2D 시각화
```
